package com.sudefi.app.web.rest;

import com.sudefi.app.SudefiApp;
import com.sudefi.app.domain.Investment;
import com.sudefi.app.repository.InvestmentRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link InvestmentResource} REST controller.
 */
@SpringBootTest(classes = SudefiApp.class)

@AutoConfigureMockMvc
@WithMockUser
public class InvestmentResourceIT {

    private static final String DEFAULT_NATURE = "A";
    private static final String UPDATED_NATURE = "B";

    private static final Instant DEFAULT_DATE_CREATION = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_DATE_CREATION = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    private static final BigDecimal DEFAULT_VALUE_US = new BigDecimal(1);
    private static final BigDecimal UPDATED_VALUE_US = new BigDecimal(2);

    private static final BigDecimal DEFAULT_VALUE_DOLLAR = new BigDecimal(1);
    private static final BigDecimal UPDATED_VALUE_DOLLAR = new BigDecimal(2);

    private static final String DEFAULT_ADDRESSWALLET = "AAAAAAAAAA";
    private static final String UPDATED_ADDRESSWALLET = "BBBBBBBBBB";

    private static final BigDecimal DEFAULT_DEPOSIT_ETH = new BigDecimal(1);
    private static final BigDecimal UPDATED_DEPOSIT_ETH = new BigDecimal(2);

    private static final BigDecimal DEFAULT_BONUS_ETH = new BigDecimal(1);
    private static final BigDecimal UPDATED_BONUS_ETH = new BigDecimal(2);

    private static final Long DEFAULT_IDCHILD = 1L;
    private static final Long UPDATED_IDCHILD = 2L;

    private static final BigDecimal DEFAULT_PROFIT_ETH = new BigDecimal(1);
    private static final BigDecimal UPDATED_PROFIT_ETH = new BigDecimal(2);

    private static final BigDecimal DEFAULT_CONSOLIDATIONVALUE_ETH = new BigDecimal(1);
    private static final BigDecimal UPDATED_CONSOLIDATIONVALUE_ETH = new BigDecimal(2);

    private static final Long DEFAULT_REFIDCHILD = 1L;
    private static final Long UPDATED_REFIDCHILD = 2L;

    @Autowired
    private InvestmentRepository investmentRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restInvestmentMockMvc;

    private Investment investment;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Investment createEntity(EntityManager em) {
        Investment investment = new Investment()
            .nature(DEFAULT_NATURE)
            .dateCreation(DEFAULT_DATE_CREATION)
            .valueUs(DEFAULT_VALUE_US)
            .valueDollar(DEFAULT_VALUE_DOLLAR)
            .addresswallet(DEFAULT_ADDRESSWALLET)
            .depositEth(DEFAULT_DEPOSIT_ETH)
            .bonusEth(DEFAULT_BONUS_ETH)
            .idchild(DEFAULT_IDCHILD)
            .profitEth(DEFAULT_PROFIT_ETH)
            .consolidationvalueEth(DEFAULT_CONSOLIDATIONVALUE_ETH)
            .refidchild(DEFAULT_REFIDCHILD);
        return investment;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Investment createUpdatedEntity(EntityManager em) {
        Investment investment = new Investment()
            .nature(UPDATED_NATURE)
            .dateCreation(UPDATED_DATE_CREATION)
            .valueUs(UPDATED_VALUE_US)
            .valueDollar(UPDATED_VALUE_DOLLAR)
            .addresswallet(UPDATED_ADDRESSWALLET)
            .depositEth(UPDATED_DEPOSIT_ETH)
            .bonusEth(UPDATED_BONUS_ETH)
            .idchild(UPDATED_IDCHILD)
            .profitEth(UPDATED_PROFIT_ETH)
            .consolidationvalueEth(UPDATED_CONSOLIDATIONVALUE_ETH)
            .refidchild(UPDATED_REFIDCHILD);
        return investment;
    }

    @BeforeEach
    public void initTest() {
        investment = createEntity(em);
    }

    @Test
    @Transactional
    public void createInvestment() throws Exception {
        int databaseSizeBeforeCreate = investmentRepository.findAll().size();

        // Create the Investment
        restInvestmentMockMvc.perform(post("/api/investments")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(investment)))
            .andExpect(status().isCreated());

        // Validate the Investment in the database
        List<Investment> investmentList = investmentRepository.findAll();
        assertThat(investmentList).hasSize(databaseSizeBeforeCreate + 1);
        Investment testInvestment = investmentList.get(investmentList.size() - 1);
        assertThat(testInvestment.getNature()).isEqualTo(DEFAULT_NATURE);
        assertThat(testInvestment.getDateCreation()).isEqualTo(DEFAULT_DATE_CREATION);
        assertThat(testInvestment.getValueUs()).isEqualTo(DEFAULT_VALUE_US);
        assertThat(testInvestment.getValueDollar()).isEqualTo(DEFAULT_VALUE_DOLLAR);
        assertThat(testInvestment.getAddresswallet()).isEqualTo(DEFAULT_ADDRESSWALLET);
        assertThat(testInvestment.getDepositEth()).isEqualTo(DEFAULT_DEPOSIT_ETH);
        assertThat(testInvestment.getBonusEth()).isEqualTo(DEFAULT_BONUS_ETH);
        assertThat(testInvestment.getIdchild()).isEqualTo(DEFAULT_IDCHILD);
        assertThat(testInvestment.getProfitEth()).isEqualTo(DEFAULT_PROFIT_ETH);
        assertThat(testInvestment.getConsolidationvalueEth()).isEqualTo(DEFAULT_CONSOLIDATIONVALUE_ETH);
        assertThat(testInvestment.getRefidchild()).isEqualTo(DEFAULT_REFIDCHILD);
    }

    @Test
    @Transactional
    public void createInvestmentWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = investmentRepository.findAll().size();

        // Create the Investment with an existing ID
        investment.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restInvestmentMockMvc.perform(post("/api/investments")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(investment)))
            .andExpect(status().isBadRequest());

        // Validate the Investment in the database
        List<Investment> investmentList = investmentRepository.findAll();
        assertThat(investmentList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void checkNatureIsRequired() throws Exception {
        int databaseSizeBeforeTest = investmentRepository.findAll().size();
        // set the field null
        investment.setNature(null);

        // Create the Investment, which fails.

        restInvestmentMockMvc.perform(post("/api/investments")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(investment)))
            .andExpect(status().isBadRequest());

        List<Investment> investmentList = investmentRepository.findAll();
        assertThat(investmentList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkAddresswalletIsRequired() throws Exception {
        int databaseSizeBeforeTest = investmentRepository.findAll().size();
        // set the field null
        investment.setAddresswallet(null);

        // Create the Investment, which fails.

        restInvestmentMockMvc.perform(post("/api/investments")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(investment)))
            .andExpect(status().isBadRequest());

        List<Investment> investmentList = investmentRepository.findAll();
        assertThat(investmentList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllInvestments() throws Exception {
        // Initialize the database
        investmentRepository.saveAndFlush(investment);

        // Get all the investmentList
        restInvestmentMockMvc.perform(get("/api/investments?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(investment.getId().intValue())))
            .andExpect(jsonPath("$.[*].nature").value(hasItem(DEFAULT_NATURE)))
            .andExpect(jsonPath("$.[*].dateCreation").value(hasItem(DEFAULT_DATE_CREATION.toString())))
            .andExpect(jsonPath("$.[*].valueUs").value(hasItem(DEFAULT_VALUE_US.intValue())))
            .andExpect(jsonPath("$.[*].valueDollar").value(hasItem(DEFAULT_VALUE_DOLLAR.intValue())))
            .andExpect(jsonPath("$.[*].addresswallet").value(hasItem(DEFAULT_ADDRESSWALLET)))
            .andExpect(jsonPath("$.[*].depositEth").value(hasItem(DEFAULT_DEPOSIT_ETH.intValue())))
            .andExpect(jsonPath("$.[*].bonusEth").value(hasItem(DEFAULT_BONUS_ETH.intValue())))
            .andExpect(jsonPath("$.[*].idchild").value(hasItem(DEFAULT_IDCHILD.intValue())))
            .andExpect(jsonPath("$.[*].profitEth").value(hasItem(DEFAULT_PROFIT_ETH.intValue())))
            .andExpect(jsonPath("$.[*].consolidationvalueEth").value(hasItem(DEFAULT_CONSOLIDATIONVALUE_ETH.intValue())))
            .andExpect(jsonPath("$.[*].refidchild").value(hasItem(DEFAULT_REFIDCHILD.intValue())));
    }
    
    @Test
    @Transactional
    public void getInvestment() throws Exception {
        // Initialize the database
        investmentRepository.saveAndFlush(investment);

        // Get the investment
        restInvestmentMockMvc.perform(get("/api/investments/{id}", investment.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(investment.getId().intValue()))
            .andExpect(jsonPath("$.nature").value(DEFAULT_NATURE))
            .andExpect(jsonPath("$.dateCreation").value(DEFAULT_DATE_CREATION.toString()))
            .andExpect(jsonPath("$.valueUs").value(DEFAULT_VALUE_US.intValue()))
            .andExpect(jsonPath("$.valueDollar").value(DEFAULT_VALUE_DOLLAR.intValue()))
            .andExpect(jsonPath("$.addresswallet").value(DEFAULT_ADDRESSWALLET))
            .andExpect(jsonPath("$.depositEth").value(DEFAULT_DEPOSIT_ETH.intValue()))
            .andExpect(jsonPath("$.bonusEth").value(DEFAULT_BONUS_ETH.intValue()))
            .andExpect(jsonPath("$.idchild").value(DEFAULT_IDCHILD.intValue()))
            .andExpect(jsonPath("$.profitEth").value(DEFAULT_PROFIT_ETH.intValue()))
            .andExpect(jsonPath("$.consolidationvalueEth").value(DEFAULT_CONSOLIDATIONVALUE_ETH.intValue()))
            .andExpect(jsonPath("$.refidchild").value(DEFAULT_REFIDCHILD.intValue()));
    }

    @Test
    @Transactional
    public void getNonExistingInvestment() throws Exception {
        // Get the investment
        restInvestmentMockMvc.perform(get("/api/investments/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateInvestment() throws Exception {
        // Initialize the database
        investmentRepository.saveAndFlush(investment);

        int databaseSizeBeforeUpdate = investmentRepository.findAll().size();

        // Update the investment
        Investment updatedInvestment = investmentRepository.findById(investment.getId()).get();
        // Disconnect from session so that the updates on updatedInvestment are not directly saved in db
        em.detach(updatedInvestment);
        updatedInvestment
            .nature(UPDATED_NATURE)
            .dateCreation(UPDATED_DATE_CREATION)
            .valueUs(UPDATED_VALUE_US)
            .valueDollar(UPDATED_VALUE_DOLLAR)
            .addresswallet(UPDATED_ADDRESSWALLET)
            .depositEth(UPDATED_DEPOSIT_ETH)
            .bonusEth(UPDATED_BONUS_ETH)
            .idchild(UPDATED_IDCHILD)
            .profitEth(UPDATED_PROFIT_ETH)
            .consolidationvalueEth(UPDATED_CONSOLIDATIONVALUE_ETH)
            .refidchild(UPDATED_REFIDCHILD);

        restInvestmentMockMvc.perform(put("/api/investments")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(updatedInvestment)))
            .andExpect(status().isOk());

        // Validate the Investment in the database
        List<Investment> investmentList = investmentRepository.findAll();
        assertThat(investmentList).hasSize(databaseSizeBeforeUpdate);
        Investment testInvestment = investmentList.get(investmentList.size() - 1);
        assertThat(testInvestment.getNature()).isEqualTo(UPDATED_NATURE);
        assertThat(testInvestment.getDateCreation()).isEqualTo(UPDATED_DATE_CREATION);
        assertThat(testInvestment.getValueUs()).isEqualTo(UPDATED_VALUE_US);
        assertThat(testInvestment.getValueDollar()).isEqualTo(UPDATED_VALUE_DOLLAR);
        assertThat(testInvestment.getAddresswallet()).isEqualTo(UPDATED_ADDRESSWALLET);
        assertThat(testInvestment.getDepositEth()).isEqualTo(UPDATED_DEPOSIT_ETH);
        assertThat(testInvestment.getBonusEth()).isEqualTo(UPDATED_BONUS_ETH);
        assertThat(testInvestment.getIdchild()).isEqualTo(UPDATED_IDCHILD);
        assertThat(testInvestment.getProfitEth()).isEqualTo(UPDATED_PROFIT_ETH);
        assertThat(testInvestment.getConsolidationvalueEth()).isEqualTo(UPDATED_CONSOLIDATIONVALUE_ETH);
        assertThat(testInvestment.getRefidchild()).isEqualTo(UPDATED_REFIDCHILD);
    }

    @Test
    @Transactional
    public void updateNonExistingInvestment() throws Exception {
        int databaseSizeBeforeUpdate = investmentRepository.findAll().size();

        // Create the Investment

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restInvestmentMockMvc.perform(put("/api/investments")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(investment)))
            .andExpect(status().isBadRequest());

        // Validate the Investment in the database
        List<Investment> investmentList = investmentRepository.findAll();
        assertThat(investmentList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteInvestment() throws Exception {
        // Initialize the database
        investmentRepository.saveAndFlush(investment);

        int databaseSizeBeforeDelete = investmentRepository.findAll().size();

        // Delete the investment
        restInvestmentMockMvc.perform(delete("/api/investments/{id}", investment.getId())
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<Investment> investmentList = investmentRepository.findAll();
        assertThat(investmentList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
