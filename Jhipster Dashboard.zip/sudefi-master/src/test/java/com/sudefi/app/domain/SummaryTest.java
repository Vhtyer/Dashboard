package com.sudefi.app.domain;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import com.sudefi.app.web.rest.TestUtil;

public class SummaryTest {

    @Test
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Summary.class);
        Summary summary1 = new Summary();
        summary1.setId(1L);
        Summary summary2 = new Summary();
        summary2.setId(summary1.getId());
        assertThat(summary1).isEqualTo(summary2);
        summary2.setId(2L);
        assertThat(summary1).isNotEqualTo(summary2);
        summary1.setId(null);
        assertThat(summary1).isNotEqualTo(summary2);
    }
}
