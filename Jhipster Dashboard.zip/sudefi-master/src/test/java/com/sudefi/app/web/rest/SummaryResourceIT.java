package com.sudefi.app.web.rest;

import com.sudefi.app.SudefiApp;
import com.sudefi.app.domain.Summary;
import com.sudefi.app.repository.SummaryRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import javax.persistence.EntityManager;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link SummaryResource} REST controller.
 */
@SpringBootTest(classes = SudefiApp.class)

@AutoConfigureMockMvc
@WithMockUser
public class SummaryResourceIT {

    private static final String DEFAULT_NATURE = "A";
    private static final String UPDATED_NATURE = "B";

    private static final Instant DEFAULT_DATE_CREATION = Instant.ofEpochMilli(0L);
    private static final Instant UPDATED_DATE_CREATION = Instant.now().truncatedTo(ChronoUnit.MILLIS);

    private static final BigDecimal DEFAULT_BONUS_ETH = new BigDecimal(1);
    private static final BigDecimal UPDATED_BONUS_ETH = new BigDecimal(2);

    private static final BigDecimal DEFAULT_BONUS_DOLLAR = new BigDecimal(1);
    private static final BigDecimal UPDATED_BONUS_DOLLAR = new BigDecimal(2);

    private static final BigDecimal DEFAULT_DEPOSIT_ETH = new BigDecimal(1);
    private static final BigDecimal UPDATED_DEPOSIT_ETH = new BigDecimal(2);

    private static final BigDecimal DEFAULT_DEPOSIT_DOLLAR = new BigDecimal(1);
    private static final BigDecimal UPDATED_DEPOSIT_DOLLAR = new BigDecimal(2);

    private static final BigDecimal DEFAULT_PROFIT_ETH = new BigDecimal(1);
    private static final BigDecimal UPDATED_PROFIT_ETH = new BigDecimal(2);

    private static final BigDecimal DEFAULT_PROFIT_DOLLAR = new BigDecimal(1);
    private static final BigDecimal UPDATED_PROFIT_DOLLAR = new BigDecimal(2);

    private static final BigDecimal DEFAULT_WITHDRAW_ETH = new BigDecimal(1);
    private static final BigDecimal UPDATED_WITHDRAW_ETH = new BigDecimal(2);

    private static final BigDecimal DEFAULT_WITHDRAW_DOLLAR = new BigDecimal(1);
    private static final BigDecimal UPDATED_WITHDRAW_DOLLAR = new BigDecimal(2);

    private static final BigDecimal DEFAULT_ACCCOUNT_BALANCE = new BigDecimal(1);
    private static final BigDecimal UPDATED_ACCCOUNT_BALANCE = new BigDecimal(2);

    @Autowired
    private SummaryRepository summaryRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restSummaryMockMvc;

    private Summary summary;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Summary createEntity(EntityManager em) {
        Summary summary = new Summary()
            .nature(DEFAULT_NATURE)
            .dateCreation(DEFAULT_DATE_CREATION)
            .bonusEth(DEFAULT_BONUS_ETH)
            .bonusDollar(DEFAULT_BONUS_DOLLAR)
            .depositEth(DEFAULT_DEPOSIT_ETH)
            .depositDollar(DEFAULT_DEPOSIT_DOLLAR)
            .profitEth(DEFAULT_PROFIT_ETH)
            .profitDollar(DEFAULT_PROFIT_DOLLAR)
            .withdrawEth(DEFAULT_WITHDRAW_ETH)
            .withdrawDollar(DEFAULT_WITHDRAW_DOLLAR)
            .acccountBalance(DEFAULT_ACCCOUNT_BALANCE);
        return summary;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Summary createUpdatedEntity(EntityManager em) {
        Summary summary = new Summary()
            .nature(UPDATED_NATURE)
            .dateCreation(UPDATED_DATE_CREATION)
            .bonusEth(UPDATED_BONUS_ETH)
            .bonusDollar(UPDATED_BONUS_DOLLAR)
            .depositEth(UPDATED_DEPOSIT_ETH)
            .depositDollar(UPDATED_DEPOSIT_DOLLAR)
            .profitEth(UPDATED_PROFIT_ETH)
            .profitDollar(UPDATED_PROFIT_DOLLAR)
            .withdrawEth(UPDATED_WITHDRAW_ETH)
            .withdrawDollar(UPDATED_WITHDRAW_DOLLAR)
            .acccountBalance(UPDATED_ACCCOUNT_BALANCE);
        return summary;
    }

    @BeforeEach
    public void initTest() {
        summary = createEntity(em);
    }

    @Test
    @Transactional
    public void createSummary() throws Exception {
        int databaseSizeBeforeCreate = summaryRepository.findAll().size();

        // Create the Summary
        restSummaryMockMvc.perform(post("/api/summaries")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(summary)))
            .andExpect(status().isCreated());

        // Validate the Summary in the database
        List<Summary> summaryList = summaryRepository.findAll();
        assertThat(summaryList).hasSize(databaseSizeBeforeCreate + 1);
        Summary testSummary = summaryList.get(summaryList.size() - 1);
        assertThat(testSummary.getNature()).isEqualTo(DEFAULT_NATURE);
        assertThat(testSummary.getDateCreation()).isEqualTo(DEFAULT_DATE_CREATION);
        assertThat(testSummary.getBonusEth()).isEqualTo(DEFAULT_BONUS_ETH);
        assertThat(testSummary.getBonusDollar()).isEqualTo(DEFAULT_BONUS_DOLLAR);
        assertThat(testSummary.getDepositEth()).isEqualTo(DEFAULT_DEPOSIT_ETH);
        assertThat(testSummary.getDepositDollar()).isEqualTo(DEFAULT_DEPOSIT_DOLLAR);
        assertThat(testSummary.getProfitEth()).isEqualTo(DEFAULT_PROFIT_ETH);
        assertThat(testSummary.getProfitDollar()).isEqualTo(DEFAULT_PROFIT_DOLLAR);
        assertThat(testSummary.getWithdrawEth()).isEqualTo(DEFAULT_WITHDRAW_ETH);
        assertThat(testSummary.getWithdrawDollar()).isEqualTo(DEFAULT_WITHDRAW_DOLLAR);
        assertThat(testSummary.getAcccountBalance()).isEqualTo(DEFAULT_ACCCOUNT_BALANCE);
    }

    @Test
    @Transactional
    public void createSummaryWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = summaryRepository.findAll().size();

        // Create the Summary with an existing ID
        summary.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restSummaryMockMvc.perform(post("/api/summaries")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(summary)))
            .andExpect(status().isBadRequest());

        // Validate the Summary in the database
        List<Summary> summaryList = summaryRepository.findAll();
        assertThat(summaryList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void checkNatureIsRequired() throws Exception {
        int databaseSizeBeforeTest = summaryRepository.findAll().size();
        // set the field null
        summary.setNature(null);

        // Create the Summary, which fails.

        restSummaryMockMvc.perform(post("/api/summaries")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(summary)))
            .andExpect(status().isBadRequest());

        List<Summary> summaryList = summaryRepository.findAll();
        assertThat(summaryList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllSummaries() throws Exception {
        // Initialize the database
        summaryRepository.saveAndFlush(summary);

        // Get all the summaryList
        restSummaryMockMvc.perform(get("/api/summaries?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(summary.getId().intValue())))
            .andExpect(jsonPath("$.[*].nature").value(hasItem(DEFAULT_NATURE)))
            .andExpect(jsonPath("$.[*].dateCreation").value(hasItem(DEFAULT_DATE_CREATION.toString())))
            .andExpect(jsonPath("$.[*].bonusEth").value(hasItem(DEFAULT_BONUS_ETH.intValue())))
            .andExpect(jsonPath("$.[*].bonusDollar").value(hasItem(DEFAULT_BONUS_DOLLAR.intValue())))
            .andExpect(jsonPath("$.[*].depositEth").value(hasItem(DEFAULT_DEPOSIT_ETH.intValue())))
            .andExpect(jsonPath("$.[*].depositDollar").value(hasItem(DEFAULT_DEPOSIT_DOLLAR.intValue())))
            .andExpect(jsonPath("$.[*].profitEth").value(hasItem(DEFAULT_PROFIT_ETH.intValue())))
            .andExpect(jsonPath("$.[*].profitDollar").value(hasItem(DEFAULT_PROFIT_DOLLAR.intValue())))
            .andExpect(jsonPath("$.[*].withdrawEth").value(hasItem(DEFAULT_WITHDRAW_ETH.intValue())))
            .andExpect(jsonPath("$.[*].withdrawDollar").value(hasItem(DEFAULT_WITHDRAW_DOLLAR.intValue())))
            .andExpect(jsonPath("$.[*].acccountBalance").value(hasItem(DEFAULT_ACCCOUNT_BALANCE.intValue())));
    }
    
    @Test
    @Transactional
    public void getSummary() throws Exception {
        // Initialize the database
        summaryRepository.saveAndFlush(summary);

        // Get the summary
        restSummaryMockMvc.perform(get("/api/summaries/{id}", summary.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(summary.getId().intValue()))
            .andExpect(jsonPath("$.nature").value(DEFAULT_NATURE))
            .andExpect(jsonPath("$.dateCreation").value(DEFAULT_DATE_CREATION.toString()))
            .andExpect(jsonPath("$.bonusEth").value(DEFAULT_BONUS_ETH.intValue()))
            .andExpect(jsonPath("$.bonusDollar").value(DEFAULT_BONUS_DOLLAR.intValue()))
            .andExpect(jsonPath("$.depositEth").value(DEFAULT_DEPOSIT_ETH.intValue()))
            .andExpect(jsonPath("$.depositDollar").value(DEFAULT_DEPOSIT_DOLLAR.intValue()))
            .andExpect(jsonPath("$.profitEth").value(DEFAULT_PROFIT_ETH.intValue()))
            .andExpect(jsonPath("$.profitDollar").value(DEFAULT_PROFIT_DOLLAR.intValue()))
            .andExpect(jsonPath("$.withdrawEth").value(DEFAULT_WITHDRAW_ETH.intValue()))
            .andExpect(jsonPath("$.withdrawDollar").value(DEFAULT_WITHDRAW_DOLLAR.intValue()))
            .andExpect(jsonPath("$.acccountBalance").value(DEFAULT_ACCCOUNT_BALANCE.intValue()));
    }

    @Test
    @Transactional
    public void getNonExistingSummary() throws Exception {
        // Get the summary
        restSummaryMockMvc.perform(get("/api/summaries/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateSummary() throws Exception {
        // Initialize the database
        summaryRepository.saveAndFlush(summary);

        int databaseSizeBeforeUpdate = summaryRepository.findAll().size();

        // Update the summary
        Summary updatedSummary = summaryRepository.findById(summary.getId()).get();
        // Disconnect from session so that the updates on updatedSummary are not directly saved in db
        em.detach(updatedSummary);
        updatedSummary
            .nature(UPDATED_NATURE)
            .dateCreation(UPDATED_DATE_CREATION)
            .bonusEth(UPDATED_BONUS_ETH)
            .bonusDollar(UPDATED_BONUS_DOLLAR)
            .depositEth(UPDATED_DEPOSIT_ETH)
            .depositDollar(UPDATED_DEPOSIT_DOLLAR)
            .profitEth(UPDATED_PROFIT_ETH)
            .profitDollar(UPDATED_PROFIT_DOLLAR)
            .withdrawEth(UPDATED_WITHDRAW_ETH)
            .withdrawDollar(UPDATED_WITHDRAW_DOLLAR)
            .acccountBalance(UPDATED_ACCCOUNT_BALANCE);

        restSummaryMockMvc.perform(put("/api/summaries")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(updatedSummary)))
            .andExpect(status().isOk());

        // Validate the Summary in the database
        List<Summary> summaryList = summaryRepository.findAll();
        assertThat(summaryList).hasSize(databaseSizeBeforeUpdate);
        Summary testSummary = summaryList.get(summaryList.size() - 1);
        assertThat(testSummary.getNature()).isEqualTo(UPDATED_NATURE);
        assertThat(testSummary.getDateCreation()).isEqualTo(UPDATED_DATE_CREATION);
        assertThat(testSummary.getBonusEth()).isEqualTo(UPDATED_BONUS_ETH);
        assertThat(testSummary.getBonusDollar()).isEqualTo(UPDATED_BONUS_DOLLAR);
        assertThat(testSummary.getDepositEth()).isEqualTo(UPDATED_DEPOSIT_ETH);
        assertThat(testSummary.getDepositDollar()).isEqualTo(UPDATED_DEPOSIT_DOLLAR);
        assertThat(testSummary.getProfitEth()).isEqualTo(UPDATED_PROFIT_ETH);
        assertThat(testSummary.getProfitDollar()).isEqualTo(UPDATED_PROFIT_DOLLAR);
        assertThat(testSummary.getWithdrawEth()).isEqualTo(UPDATED_WITHDRAW_ETH);
        assertThat(testSummary.getWithdrawDollar()).isEqualTo(UPDATED_WITHDRAW_DOLLAR);
        assertThat(testSummary.getAcccountBalance()).isEqualTo(UPDATED_ACCCOUNT_BALANCE);
    }

    @Test
    @Transactional
    public void updateNonExistingSummary() throws Exception {
        int databaseSizeBeforeUpdate = summaryRepository.findAll().size();

        // Create the Summary

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restSummaryMockMvc.perform(put("/api/summaries")
            .contentType(MediaType.APPLICATION_JSON)
            .content(TestUtil.convertObjectToJsonBytes(summary)))
            .andExpect(status().isBadRequest());

        // Validate the Summary in the database
        List<Summary> summaryList = summaryRepository.findAll();
        assertThat(summaryList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteSummary() throws Exception {
        // Initialize the database
        summaryRepository.saveAndFlush(summary);

        int databaseSizeBeforeDelete = summaryRepository.findAll().size();

        // Delete the summary
        restSummaryMockMvc.perform(delete("/api/summaries/{id}", summary.getId())
            .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<Summary> summaryList = summaryRepository.findAll();
        assertThat(summaryList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
