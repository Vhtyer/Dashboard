package com.sudefi.app.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

import javax.persistence.*;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;
import java.math.BigDecimal;
import java.time.Instant;

/**
 * The investment Entity.
 */
@ApiModel(description = "The investment Entity.")
@Entity
@Table(name = "investment")
public class Investment implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Size(max = 1)
    @Column(name = "nature", length = 1, nullable = false)
    private String nature;

    @Column(name = "date_creation")
    private Instant dateCreation;

    @Column(name = "value_us", precision = 21, scale = 2)
    private BigDecimal valueUs;

    @Column(name = "value_dollar", precision = 21, scale = 2)
    private BigDecimal valueDollar;

    @NotNull
    @Column(name = "addresswallet", nullable = false)
    private String addresswallet;

    @Column(name = "deposit_eth", precision = 21, scale = 2)
    private BigDecimal depositEth;

    @Column(name = "bonus_eth", precision = 21, scale = 2)
    private BigDecimal bonusEth;

    @Column(name = "idchild")
    private Long idchild;

    @Column(name = "profit_eth", precision = 21, scale = 2)
    private BigDecimal profitEth;

    @Column(name = "consolidationvalue_eth", precision = 21, scale = 2)
    private BigDecimal consolidationvalueEth;

    @Column(name = "refidchild")
    private Long refidchild;

    @ManyToOne
    @JsonIgnoreProperties("investments")
    private Investor investorid;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNature() {
        return nature;
    }

    public Investment nature(String nature) {
        this.nature = nature;
        return this;
    }

    public void setNature(String nature) {
        this.nature = nature;
    }

    public Instant getDateCreation() {
        return dateCreation;
    }

    public Investment dateCreation(Instant dateCreation) {
        this.dateCreation = dateCreation;
        return this;
    }

    public void setDateCreation(Instant dateCreation) {
        this.dateCreation = dateCreation;
    }

    public BigDecimal getValueUs() {
        return valueUs;
    }

    public Investment valueUs(BigDecimal valueUs) {
        this.valueUs = valueUs;
        return this;
    }

    public void setValueUs(BigDecimal valueUs) {
        this.valueUs = valueUs;
    }

    public BigDecimal getValueDollar() {
        return valueDollar;
    }

    public Investment valueDollar(BigDecimal valueDollar) {
        this.valueDollar = valueDollar;
        return this;
    }

    public void setValueDollar(BigDecimal valueDollar) {
        this.valueDollar = valueDollar;
    }

    public String getAddresswallet() {
        return addresswallet;
    }

    public Investment addresswallet(String addresswallet) {
        this.addresswallet = addresswallet;
        return this;
    }

    public void setAddresswallet(String addresswallet) {
        this.addresswallet = addresswallet;
    }

    public BigDecimal getDepositEth() {
        return depositEth;
    }

    public Investment depositEth(BigDecimal depositEth) {
        this.depositEth = depositEth;
        return this;
    }

    public void setDepositEth(BigDecimal depositEth) {
        this.depositEth = depositEth;
    }

    public BigDecimal getBonusEth() {
        return bonusEth;
    }

    public Investment bonusEth(BigDecimal bonusEth) {
        this.bonusEth = bonusEth;
        return this;
    }

    public void setBonusEth(BigDecimal bonusEth) {
        this.bonusEth = bonusEth;
    }

    public Long getIdchild() {
        return idchild;
    }

    public Investment idchild(Long idchild) {
        this.idchild = idchild;
        return this;
    }

    public void setIdchild(Long idchild) {
        this.idchild = idchild;
    }

    public BigDecimal getProfitEth() {
        return profitEth;
    }

    public Investment profitEth(BigDecimal profitEth) {
        this.profitEth = profitEth;
        return this;
    }

    public void setProfitEth(BigDecimal profitEth) {
        this.profitEth = profitEth;
    }

    public BigDecimal getConsolidationvalueEth() {
        return consolidationvalueEth;
    }

    public Investment consolidationvalueEth(BigDecimal consolidationvalueEth) {
        this.consolidationvalueEth = consolidationvalueEth;
        return this;
    }

    public void setConsolidationvalueEth(BigDecimal consolidationvalueEth) {
        this.consolidationvalueEth = consolidationvalueEth;
    }

    public Long getRefidchild() {
        return refidchild;
    }

    public Investment refidchild(Long refidchild) {
        this.refidchild = refidchild;
        return this;
    }

    public void setRefidchild(Long refidchild) {
        this.refidchild = refidchild;
    }

    public Investor getInvestorid() {
        return investorid;
    }

    public Investment investorid(Investor investor) {
        this.investorid = investor;
        return this;
    }

    public void setInvestorid(Investor investor) {
        this.investorid = investor;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Investment)) {
            return false;
        }
        return id != null && id.equals(((Investment) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Investment{" +
            "id=" + getId() +
            ", nature='" + getNature() + "'" +
            ", dateCreation='" + getDateCreation() + "'" +
            ", valueUs=" + getValueUs() +
            ", valueDollar=" + getValueDollar() +
            ", addresswallet='" + getAddresswallet() + "'" +
            ", depositEth=" + getDepositEth() +
            ", bonusEth=" + getBonusEth() +
            ", idchild=" + getIdchild() +
            ", profitEth=" + getProfitEth() +
            ", consolidationvalueEth=" + getConsolidationvalueEth() +
            ", refidchild=" + getRefidchild() +
            "}";
    }
}
