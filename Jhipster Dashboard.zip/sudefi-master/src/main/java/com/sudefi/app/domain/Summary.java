package com.sudefi.app.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;

import javax.persistence.*;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;
import java.math.BigDecimal;
import java.time.Instant;

/**
 * The Summary Entity.
 */
@ApiModel(description = "The Summary Entity.")
@Entity
@Table(name = "summary")
public class Summary implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Size(max = 1)
    @Column(name = "nature", length = 1, nullable = false)
    private String nature;

    @Column(name = "date_creation")
    private Instant dateCreation;

    @Column(name = "bonus_eth", precision = 21, scale = 2)
    private BigDecimal bonusEth;

    @Column(name = "bonus_dollar", precision = 21, scale = 2)
    private BigDecimal bonusDollar;

    @Column(name = "deposit_eth", precision = 21, scale = 2)
    private BigDecimal depositEth;

    @Column(name = "deposit_dollar", precision = 21, scale = 2)
    private BigDecimal depositDollar;

    @Column(name = "profit_eth", precision = 21, scale = 2)
    private BigDecimal profitEth;

    @Column(name = "profit_dollar", precision = 21, scale = 2)
    private BigDecimal profitDollar;

    @Column(name = "withdraw_eth", precision = 21, scale = 2)
    private BigDecimal withdrawEth;

    @Column(name = "withdraw_dollar", precision = 21, scale = 2)
    private BigDecimal withdrawDollar;

    @Column(name = "acccount_balance", precision = 21, scale = 2)
    private BigDecimal acccountBalance;

    @ManyToOne
    @JsonIgnoreProperties("summaries")
    private Investor investorid;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNature() {
        return nature;
    }

    public Summary nature(String nature) {
        this.nature = nature;
        return this;
    }

    public void setNature(String nature) {
        this.nature = nature;
    }

    public Instant getDateCreation() {
        return dateCreation;
    }

    public Summary dateCreation(Instant dateCreation) {
        this.dateCreation = dateCreation;
        return this;
    }

    public void setDateCreation(Instant dateCreation) {
        this.dateCreation = dateCreation;
    }

    public BigDecimal getBonusEth() {
        return bonusEth;
    }

    public Summary bonusEth(BigDecimal bonusEth) {
        this.bonusEth = bonusEth;
        return this;
    }

    public void setBonusEth(BigDecimal bonusEth) {
        this.bonusEth = bonusEth;
    }

    public BigDecimal getBonusDollar() {
        return bonusDollar;
    }

    public Summary bonusDollar(BigDecimal bonusDollar) {
        this.bonusDollar = bonusDollar;
        return this;
    }

    public void setBonusDollar(BigDecimal bonusDollar) {
        this.bonusDollar = bonusDollar;
    }

    public BigDecimal getDepositEth() {
        return depositEth;
    }

    public Summary depositEth(BigDecimal depositEth) {
        this.depositEth = depositEth;
        return this;
    }

    public void setDepositEth(BigDecimal depositEth) {
        this.depositEth = depositEth;
    }

    public BigDecimal getDepositDollar() {
        return depositDollar;
    }

    public Summary depositDollar(BigDecimal depositDollar) {
        this.depositDollar = depositDollar;
        return this;
    }

    public void setDepositDollar(BigDecimal depositDollar) {
        this.depositDollar = depositDollar;
    }

    public BigDecimal getProfitEth() {
        return profitEth;
    }

    public Summary profitEth(BigDecimal profitEth) {
        this.profitEth = profitEth;
        return this;
    }

    public void setProfitEth(BigDecimal profitEth) {
        this.profitEth = profitEth;
    }

    public BigDecimal getProfitDollar() {
        return profitDollar;
    }

    public Summary profitDollar(BigDecimal profitDollar) {
        this.profitDollar = profitDollar;
        return this;
    }

    public void setProfitDollar(BigDecimal profitDollar) {
        this.profitDollar = profitDollar;
    }

    public BigDecimal getWithdrawEth() {
        return withdrawEth;
    }

    public Summary withdrawEth(BigDecimal withdrawEth) {
        this.withdrawEth = withdrawEth;
        return this;
    }

    public void setWithdrawEth(BigDecimal withdrawEth) {
        this.withdrawEth = withdrawEth;
    }

    public BigDecimal getWithdrawDollar() {
        return withdrawDollar;
    }

    public Summary withdrawDollar(BigDecimal withdrawDollar) {
        this.withdrawDollar = withdrawDollar;
        return this;
    }

    public void setWithdrawDollar(BigDecimal withdrawDollar) {
        this.withdrawDollar = withdrawDollar;
    }

    public BigDecimal getAcccountBalance() {
        return acccountBalance;
    }

    public Summary acccountBalance(BigDecimal acccountBalance) {
        this.acccountBalance = acccountBalance;
        return this;
    }

    public void setAcccountBalance(BigDecimal acccountBalance) {
        this.acccountBalance = acccountBalance;
    }

    public Investor getInvestorid() {
        return investorid;
    }

    public Summary investorid(Investor investor) {
        this.investorid = investor;
        return this;
    }

    public void setInvestorid(Investor investor) {
        this.investorid = investor;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Summary)) {
            return false;
        }
        return id != null && id.equals(((Summary) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Summary{" +
            "id=" + getId() +
            ", nature='" + getNature() + "'" +
            ", dateCreation='" + getDateCreation() + "'" +
            ", bonusEth=" + getBonusEth() +
            ", bonusDollar=" + getBonusDollar() +
            ", depositEth=" + getDepositEth() +
            ", depositDollar=" + getDepositDollar() +
            ", profitEth=" + getProfitEth() +
            ", profitDollar=" + getProfitDollar() +
            ", withdrawEth=" + getWithdrawEth() +
            ", withdrawDollar=" + getWithdrawDollar() +
            ", acccountBalance=" + getAcccountBalance() +
            "}";
    }
}
