/**
 * Data Transfer Objects.
 */
package com.sudefi.app.service.dto;
