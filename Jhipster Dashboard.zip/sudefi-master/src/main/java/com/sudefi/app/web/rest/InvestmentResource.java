package com.sudefi.app.web.rest;

import com.sudefi.app.domain.Investment;
import com.sudefi.app.repository.InvestmentRepository;
import com.sudefi.app.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.sudefi.app.domain.Investment}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class InvestmentResource {

    private final Logger log = LoggerFactory.getLogger(InvestmentResource.class);

    private static final String ENTITY_NAME = "investment";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final InvestmentRepository investmentRepository;

    public InvestmentResource(InvestmentRepository investmentRepository) {
        this.investmentRepository = investmentRepository;
    }

    /**
     * {@code POST  /investments} : Create a new investment.
     *
     * @param investment the investment to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new investment, or with status {@code 400 (Bad Request)} if the investment has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/investments")
    public ResponseEntity<Investment> createInvestment(@Valid @RequestBody Investment investment) throws URISyntaxException {
        log.debug("REST request to save Investment : {}", investment);
        if (investment.getId() != null) {
            throw new BadRequestAlertException("A new investment cannot already have an ID", ENTITY_NAME, "idexists");
        }
        Investment result = investmentRepository.save(investment);
        return ResponseEntity.created(new URI("/api/investments/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /investments} : Updates an existing investment.
     *
     * @param investment the investment to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated investment,
     * or with status {@code 400 (Bad Request)} if the investment is not valid,
     * or with status {@code 500 (Internal Server Error)} if the investment couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/investments")
    public ResponseEntity<Investment> updateInvestment(@Valid @RequestBody Investment investment) throws URISyntaxException {
        log.debug("REST request to update Investment : {}", investment);
        if (investment.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        Investment result = investmentRepository.save(investment);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, investment.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /investments} : get all the investments.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of investments in body.
     */
    @GetMapping("/investments")
    public List<Investment> getAllInvestments() {
        log.debug("REST request to get all Investments");
        return investmentRepository.findAll();
    }

    /**
     * {@code GET  /investments/:id} : get the "id" investment.
     *
     * @param id the id of the investment to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the investment, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/investments/{id}")
    public ResponseEntity<Investment> getInvestment(@PathVariable Long id) {
        log.debug("REST request to get Investment : {}", id);
        Optional<Investment> investment = investmentRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(investment);
    }

    /**
     * {@code DELETE  /investments/:id} : delete the "id" investment.
     *
     * @param id the id of the investment to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/investments/{id}")
    public ResponseEntity<Void> deleteInvestment(@PathVariable Long id) {
        log.debug("REST request to delete Investment : {}", id);
        investmentRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
