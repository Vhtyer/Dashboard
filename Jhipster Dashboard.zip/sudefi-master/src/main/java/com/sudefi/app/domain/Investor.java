package com.sudefi.app.domain;

import io.swagger.annotations.ApiModel;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Objects;
import java.util.HashSet;
import java.util.Set;

/**
 * The investor Entity.
 */
@ApiModel(description = "The investor Entity.")
@Entity
@Table(name = "investor")
public class Investor implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "pais")
    private String pais;

    @Column(name = "addresswallet")
    private String addresswallet;

    @Column(name = "firstname")
    private String firstname;

    @Column(name = "lastname")
    private String lastname;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Column(name = "fatherid")
    private Long fatherid;

    @OneToMany(mappedBy = "investorid")
    private Set<Investment> investments = new HashSet<>();

    @OneToMany(mappedBy = "investorid")
    private Set<Summary> summaries = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPais() {
        return pais;
    }

    public Investor pais(String pais) {
        this.pais = pais;
        return this;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getAddresswallet() {
        return addresswallet;
    }

    public Investor addresswallet(String addresswallet) {
        this.addresswallet = addresswallet;
        return this;
    }

    public void setAddresswallet(String addresswallet) {
        this.addresswallet = addresswallet;
    }

    public String getFirstname() {
        return firstname;
    }

    public Investor firstname(String firstname) {
        this.firstname = firstname;
        return this;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public Investor lastname(String lastname) {
        this.lastname = lastname;
        return this;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public Investor phoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Long getFatherid() {
        return fatherid;
    }

    public Investor fatherid(Long fatherid) {
        this.fatherid = fatherid;
        return this;
    }

    public void setFatherid(Long fatherid) {
        this.fatherid = fatherid;
    }

    public Set<Investment> getInvestments() {
        return investments;
    }

    public Investor investments(Set<Investment> investments) {
        this.investments = investments;
        return this;
    }

    public Investor addInvestment(Investment investment) {
        this.investments.add(investment);
        investment.setInvestorid(this);
        return this;
    }

    public Investor removeInvestment(Investment investment) {
        this.investments.remove(investment);
        investment.setInvestorid(null);
        return this;
    }

    public void setInvestments(Set<Investment> investments) {
        this.investments = investments;
    }

    public Set<Summary> getSummaries() {
        return summaries;
    }

    public Investor summaries(Set<Summary> summaries) {
        this.summaries = summaries;
        return this;
    }

    public Investor addSummary(Summary summary) {
        this.summaries.add(summary);
        summary.setInvestorid(this);
        return this;
    }

    public Investor removeSummary(Summary summary) {
        this.summaries.remove(summary);
        summary.setInvestorid(null);
        return this;
    }

    public void setSummaries(Set<Summary> summaries) {
        this.summaries = summaries;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Investor)) {
            return false;
        }
        return id != null && id.equals(((Investor) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Investor{" +
            "id=" + getId() +
            ", pais='" + getPais() + "'" +
            ", addresswallet='" + getAddresswallet() + "'" +
            ", firstname='" + getFirstname() + "'" +
            ", lastname='" + getLastname() + "'" +
            ", phoneNumber='" + getPhoneNumber() + "'" +
            ", fatherid=" + getFatherid() +
            "}";
    }
}
