package com.sudefi.app.web.rest;

import com.sudefi.app.domain.Summary;
import com.sudefi.app.repository.SummaryRepository;
import com.sudefi.app.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.sudefi.app.domain.Summary}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class SummaryResource {

    private final Logger log = LoggerFactory.getLogger(SummaryResource.class);

    private static final String ENTITY_NAME = "summary";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final SummaryRepository summaryRepository;

    public SummaryResource(SummaryRepository summaryRepository) {
        this.summaryRepository = summaryRepository;
    }

    /**
     * {@code POST  /summaries} : Create a new summary.
     *
     * @param summary the summary to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new summary, or with status {@code 400 (Bad Request)} if the summary has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/summaries")
    public ResponseEntity<Summary> createSummary(@Valid @RequestBody Summary summary) throws URISyntaxException {
        log.debug("REST request to save Summary : {}", summary);
        if (summary.getId() != null) {
            throw new BadRequestAlertException("A new summary cannot already have an ID", ENTITY_NAME, "idexists");
        }
        Summary result = summaryRepository.save(summary);
        return ResponseEntity.created(new URI("/api/summaries/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /summaries} : Updates an existing summary.
     *
     * @param summary the summary to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated summary,
     * or with status {@code 400 (Bad Request)} if the summary is not valid,
     * or with status {@code 500 (Internal Server Error)} if the summary couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/summaries")
    public ResponseEntity<Summary> updateSummary(@Valid @RequestBody Summary summary) throws URISyntaxException {
        log.debug("REST request to update Summary : {}", summary);
        if (summary.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        Summary result = summaryRepository.save(summary);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, summary.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /summaries} : get all the summaries.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of summaries in body.
     */
    @GetMapping("/summaries")
    public List<Summary> getAllSummaries() {
        log.debug("REST request to get all Summaries");
        return summaryRepository.findAll();
    }

    /**
     * {@code GET  /summaries/:id} : get the "id" summary.
     *
     * @param id the id of the summary to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the summary, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/summaries/{id}")
    public ResponseEntity<Summary> getSummary(@PathVariable Long id) {
        log.debug("REST request to get Summary : {}", id);
        Optional<Summary> summary = summaryRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(summary);
    }

    /**
     * {@code DELETE  /summaries/:id} : delete the "id" summary.
     *
     * @param id the id of the summary to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/summaries/{id}")
    public ResponseEntity<Void> deleteSummary(@PathVariable Long id) {
        log.debug("REST request to delete Summary : {}", id);
        summaryRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
