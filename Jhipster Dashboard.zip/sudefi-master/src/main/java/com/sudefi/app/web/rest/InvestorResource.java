package com.sudefi.app.web.rest;

import com.sudefi.app.domain.Investor;
import com.sudefi.app.repository.InvestorRepository;
import com.sudefi.app.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.sudefi.app.domain.Investor}.
 */
@RestController
@RequestMapping("/api")
@Transactional
public class InvestorResource {

    private final Logger log = LoggerFactory.getLogger(InvestorResource.class);

    private static final String ENTITY_NAME = "investor";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final InvestorRepository investorRepository;

    public InvestorResource(InvestorRepository investorRepository) {
        this.investorRepository = investorRepository;
    }

    /**
     * {@code POST  /investors} : Create a new investor.
     *
     * @param investor the investor to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new investor, or with status {@code 400 (Bad Request)} if the investor has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/investors")
    public ResponseEntity<Investor> createInvestor(@RequestBody Investor investor) throws URISyntaxException {
        log.debug("REST request to save Investor : {}", investor);
        if (investor.getId() != null) {
            throw new BadRequestAlertException("A new investor cannot already have an ID", ENTITY_NAME, "idexists");
        }
        Investor result = investorRepository.save(investor);
        return ResponseEntity.created(new URI("/api/investors/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /investors} : Updates an existing investor.
     *
     * @param investor the investor to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated investor,
     * or with status {@code 400 (Bad Request)} if the investor is not valid,
     * or with status {@code 500 (Internal Server Error)} if the investor couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/investors")
    public ResponseEntity<Investor> updateInvestor(@RequestBody Investor investor) throws URISyntaxException {
        log.debug("REST request to update Investor : {}", investor);
        if (investor.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        Investor result = investorRepository.save(investor);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, investor.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /investors} : get all the investors.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of investors in body.
     */
    @GetMapping("/investors")
    public List<Investor> getAllInvestors() {
        log.debug("REST request to get all Investors");
        return investorRepository.findAll();
    }

    /**
     * {@code GET  /investors/:id} : get the "id" investor.
     *
     * @param id the id of the investor to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the investor, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/investors/{id}")
    public ResponseEntity<Investor> getInvestor(@PathVariable Long id) {
        log.debug("REST request to get Investor : {}", id);
        Optional<Investor> investor = investorRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(investor);
    }

    /**
     * {@code DELETE  /investors/:id} : delete the "id" investor.
     *
     * @param id the id of the investor to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/investors/{id}")
    public ResponseEntity<Void> deleteInvestor(@PathVariable Long id) {
        log.debug("REST request to delete Investor : {}", id);
        investorRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString())).build();
    }
}
