/**
 * Spring Data JPA repositories.
 */
package com.sudefi.app.repository;
