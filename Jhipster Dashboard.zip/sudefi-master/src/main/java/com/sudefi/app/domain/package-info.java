/**
 * JPA domain objects.
 */
package com.sudefi.app.domain;
