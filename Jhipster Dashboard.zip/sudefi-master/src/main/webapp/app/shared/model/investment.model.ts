import { Moment } from 'moment';
import { IInvestor } from 'app/shared/model/investor.model';

export interface IInvestment {
  id?: number;
  nature?: string;
  dateCreation?: Moment;
  valueUs?: number;
  valueDollar?: number;
  addresswallet?: string;
  depositEth?: number;
  bonusEth?: number;
  idchild?: number;
  profitEth?: number;
  consolidationvalueEth?: number;
  refidchild?: number;
  investorid?: IInvestor;
}

export const defaultValue: Readonly<IInvestment> = {};
