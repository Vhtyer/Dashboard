import { IInvestment } from 'app/shared/model/investment.model';
import { ISummary } from 'app/shared/model/summary.model';

export interface IInvestor {
  id?: number;
  pais?: string;
  addresswallet?: string;
  firstname?: string;
  lastname?: string;
  phoneNumber?: string;
  fatherid?: number;
  investments?: IInvestment[];
  summaries?: ISummary[];
}

export const defaultValue: Readonly<IInvestor> = {};
