import { Moment } from 'moment';
import { IInvestor } from 'app/shared/model/investor.model';

export interface ISummary {
  id?: number;
  nature?: string;
  dateCreation?: Moment;
  bonusEth?: number;
  bonusDollar?: number;
  depositEth?: number;
  depositDollar?: number;
  profitEth?: number;
  profitDollar?: number;
  withdrawEth?: number;
  withdrawDollar?: number;
  acccountBalance?: number;
  investorid?: IInvestor;
}

export const defaultValue: Readonly<ISummary> = {};
