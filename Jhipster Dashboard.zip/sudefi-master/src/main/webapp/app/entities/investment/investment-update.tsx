import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { Link, RouteComponentProps } from 'react-router-dom';
import { Button, Row, Col, Label } from 'reactstrap';
import { AvFeedback, AvForm, AvGroup, AvInput, AvField } from 'availity-reactstrap-validation';
import { Translate, translate, ICrudGetAction, ICrudGetAllAction, ICrudPutAction } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IRootState } from 'app/shared/reducers';

import { IInvestor } from 'app/shared/model/investor.model';
import { getEntities as getInvestors } from 'app/entities/investor/investor.reducer';
import { getEntity, updateEntity, createEntity, reset } from './investment.reducer';
import { IInvestment } from 'app/shared/model/investment.model';
import { convertDateTimeFromServer, convertDateTimeToServer, displayDefaultDateTime } from 'app/shared/util/date-utils';
import { mapIdList } from 'app/shared/util/entity-utils';

export interface IInvestmentUpdateProps extends StateProps, DispatchProps, RouteComponentProps<{ id: string }> {}

export const InvestmentUpdate = (props: IInvestmentUpdateProps) => {
  const [investoridId, setInvestoridId] = useState('0');
  const [isNew, setIsNew] = useState(!props.match.params || !props.match.params.id);

  const { investmentEntity, investors, loading, updating } = props;

  const handleClose = () => {
    props.history.push('/investment');
  };

  useEffect(() => {
    if (isNew) {
      props.reset();
    } else {
      props.getEntity(props.match.params.id);
    }

    props.getInvestors();
  }, []);

  useEffect(() => {
    if (props.updateSuccess) {
      handleClose();
    }
  }, [props.updateSuccess]);

  const saveEntity = (event, errors, values) => {
    values.dateCreation = convertDateTimeToServer(values.dateCreation);

    if (errors.length === 0) {
      const entity = {
        ...investmentEntity,
        ...values
      };

      if (isNew) {
        props.createEntity(entity);
      } else {
        props.updateEntity(entity);
      }
    }
  };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="sudefiApp.investment.home.createOrEditLabel">
            <Translate contentKey="sudefiApp.investment.home.createOrEditLabel">Create or edit a Investment</Translate>
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <AvForm model={isNew ? {} : investmentEntity} onSubmit={saveEntity}>
              {!isNew ? (
                <AvGroup>
                  <Label for="investment-id">
                    <Translate contentKey="global.field.id">ID</Translate>
                  </Label>
                  <AvInput id="investment-id" type="text" className="form-control" name="id" required readOnly />
                </AvGroup>
              ) : null}
              <AvGroup>
                <Label id="natureLabel" for="investment-nature">
                  <Translate contentKey="sudefiApp.investment.nature">Nature</Translate>
                </Label>
                <AvField
                  id="investment-nature"
                  type="text"
                  name="nature"
                  validate={{
                    required: { value: true, errorMessage: translate('entity.validation.required') },
                    maxLength: { value: 1, errorMessage: translate('entity.validation.maxlength', { max: 1 }) }
                  }}
                />
              </AvGroup>
              <AvGroup>
                <Label id="dateCreationLabel" for="investment-dateCreation">
                  <Translate contentKey="sudefiApp.investment.dateCreation">Date Creation</Translate>
                </Label>
                <AvInput
                  id="investment-dateCreation"
                  type="datetime-local"
                  className="form-control"
                  name="dateCreation"
                  placeholder={'YYYY-MM-DD HH:mm'}
                  value={isNew ? displayDefaultDateTime() : convertDateTimeFromServer(props.investmentEntity.dateCreation)}
                />
              </AvGroup>
              <AvGroup>
                <Label id="valueUsLabel" for="investment-valueUs">
                  <Translate contentKey="sudefiApp.investment.valueUs">Value Us</Translate>
                </Label>
                <AvField id="investment-valueUs" type="text" name="valueUs" />
              </AvGroup>
              <AvGroup>
                <Label id="valueDollarLabel" for="investment-valueDollar">
                  <Translate contentKey="sudefiApp.investment.valueDollar">Value Dollar</Translate>
                </Label>
                <AvField id="investment-valueDollar" type="text" name="valueDollar" />
              </AvGroup>
              <AvGroup>
                <Label id="addresswalletLabel" for="investment-addresswallet">
                  <Translate contentKey="sudefiApp.investment.addresswallet">Addresswallet</Translate>
                </Label>
                <AvField
                  id="investment-addresswallet"
                  type="text"
                  name="addresswallet"
                  validate={{
                    required: { value: true, errorMessage: translate('entity.validation.required') }
                  }}
                />
              </AvGroup>
              <AvGroup>
                <Label id="depositEthLabel" for="investment-depositEth">
                  <Translate contentKey="sudefiApp.investment.depositEth">Deposit Eth</Translate>
                </Label>
                <AvField id="investment-depositEth" type="text" name="depositEth" />
              </AvGroup>
              <AvGroup>
                <Label id="bonusEthLabel" for="investment-bonusEth">
                  <Translate contentKey="sudefiApp.investment.bonusEth">Bonus Eth</Translate>
                </Label>
                <AvField id="investment-bonusEth" type="text" name="bonusEth" />
              </AvGroup>
              <AvGroup>
                <Label id="idchildLabel" for="investment-idchild">
                  <Translate contentKey="sudefiApp.investment.idchild">Idchild</Translate>
                </Label>
                <AvField id="investment-idchild" type="string" className="form-control" name="idchild" />
              </AvGroup>
              <AvGroup>
                <Label id="profitEthLabel" for="investment-profitEth">
                  <Translate contentKey="sudefiApp.investment.profitEth">Profit Eth</Translate>
                </Label>
                <AvField id="investment-profitEth" type="text" name="profitEth" />
              </AvGroup>
              <AvGroup>
                <Label id="consolidationvalueEthLabel" for="investment-consolidationvalueEth">
                  <Translate contentKey="sudefiApp.investment.consolidationvalueEth">Consolidationvalue Eth</Translate>
                </Label>
                <AvField id="investment-consolidationvalueEth" type="text" name="consolidationvalueEth" />
              </AvGroup>
              <AvGroup>
                <Label id="refidchildLabel" for="investment-refidchild">
                  <Translate contentKey="sudefiApp.investment.refidchild">Refidchild</Translate>
                </Label>
                <AvField id="investment-refidchild" type="string" className="form-control" name="refidchild" />
              </AvGroup>
              <AvGroup>
                <Label for="investment-investorid">
                  <Translate contentKey="sudefiApp.investment.investorid">Investorid</Translate>
                </Label>
                <AvInput id="investment-investorid" type="select" className="form-control" name="investorid.id">
                  <option value="" key="0" />
                  {investors
                    ? investors.map(otherEntity => (
                        <option value={otherEntity.id} key={otherEntity.id}>
                          {otherEntity.id}
                        </option>
                      ))
                    : null}
                </AvInput>
              </AvGroup>
              <Button tag={Link} id="cancel-save" to="/investment" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">
                  <Translate contentKey="entity.action.back">Back</Translate>
                </span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp;
                <Translate contentKey="entity.action.save">Save</Translate>
              </Button>
            </AvForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

const mapStateToProps = (storeState: IRootState) => ({
  investors: storeState.investor.entities,
  investmentEntity: storeState.investment.entity,
  loading: storeState.investment.loading,
  updating: storeState.investment.updating,
  updateSuccess: storeState.investment.updateSuccess
});

const mapDispatchToProps = {
  getInvestors,
  getEntity,
  updateEntity,
  createEntity,
  reset
};

type StateProps = ReturnType<typeof mapStateToProps>;
type DispatchProps = typeof mapDispatchToProps;

export default connect(mapStateToProps, mapDispatchToProps)(InvestmentUpdate);
