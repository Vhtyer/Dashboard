import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { Link, RouteComponentProps } from 'react-router-dom';
import { Button, Col, Row, Table } from 'reactstrap';
import { Translate, ICrudGetAllAction, TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { IRootState } from 'app/shared/reducers';
import { getEntities } from './investment.reducer';
import { IInvestment } from 'app/shared/model/investment.model';
import { APP_DATE_FORMAT, APP_LOCAL_DATE_FORMAT } from 'app/config/constants';

export interface IInvestmentProps extends StateProps, DispatchProps, RouteComponentProps<{ url: string }> {}

export const Investment = (props: IInvestmentProps) => {
  useEffect(() => {
    props.getEntities();
  }, []);

  const { investmentList, match, loading } = props;
  return (
    <div>
      <h2 id="investment-heading">
        <Translate contentKey="sudefiApp.investment.home.title">Investments</Translate>
        <Link to={`${match.url}/new`} className="btn btn-primary float-right jh-create-entity" id="jh-create-entity">
          <FontAwesomeIcon icon="plus" />
          &nbsp;
          <Translate contentKey="sudefiApp.investment.home.createLabel">Create new Investment</Translate>
        </Link>
      </h2>
      <div className="table-responsive">
        {investmentList && investmentList.length > 0 ? (
          <Table responsive>
            <thead>
              <tr>
                <th>
                  <Translate contentKey="global.field.id">ID</Translate>
                </th>
                <th>
                  <Translate contentKey="sudefiApp.investment.nature">Nature</Translate>
                </th>
                <th>
                  <Translate contentKey="sudefiApp.investment.dateCreation">Date Creation</Translate>
                </th>
                <th>
                  <Translate contentKey="sudefiApp.investment.valueUs">Value Us</Translate>
                </th>
                <th>
                  <Translate contentKey="sudefiApp.investment.valueDollar">Value Dollar</Translate>
                </th>
                <th>
                  <Translate contentKey="sudefiApp.investment.addresswallet">Addresswallet</Translate>
                </th>
                <th>
                  <Translate contentKey="sudefiApp.investment.depositEth">Deposit Eth</Translate>
                </th>
                <th>
                  <Translate contentKey="sudefiApp.investment.bonusEth">Bonus Eth</Translate>
                </th>
                <th>
                  <Translate contentKey="sudefiApp.investment.idchild">Idchild</Translate>
                </th>
                <th>
                  <Translate contentKey="sudefiApp.investment.profitEth">Profit Eth</Translate>
                </th>
                <th>
                  <Translate contentKey="sudefiApp.investment.consolidationvalueEth">Consolidationvalue Eth</Translate>
                </th>
                <th>
                  <Translate contentKey="sudefiApp.investment.refidchild">Refidchild</Translate>
                </th>
                <th>
                  <Translate contentKey="sudefiApp.investment.investorid">Investorid</Translate>
                </th>
                <th />
              </tr>
            </thead>
            <tbody>
              {investmentList.map((investment, i) => (
                <tr key={`entity-${i}`}>
                  <td>
                    <Button tag={Link} to={`${match.url}/${investment.id}`} color="link" size="sm">
                      {investment.id}
                    </Button>
                  </td>
                  <td>{investment.nature}</td>
                  <td>
                    <TextFormat type="date" value={investment.dateCreation} format={APP_DATE_FORMAT} />
                  </td>
                  <td>{investment.valueUs}</td>
                  <td>{investment.valueDollar}</td>
                  <td>{investment.addresswallet}</td>
                  <td>{investment.depositEth}</td>
                  <td>{investment.bonusEth}</td>
                  <td>{investment.idchild}</td>
                  <td>{investment.profitEth}</td>
                  <td>{investment.consolidationvalueEth}</td>
                  <td>{investment.refidchild}</td>
                  <td>
                    {investment.investorid ? <Link to={`investor/${investment.investorid.id}`}>{investment.investorid.id}</Link> : ''}
                  </td>
                  <td className="text-right">
                    <div className="btn-group flex-btn-group-container">
                      <Button tag={Link} to={`${match.url}/${investment.id}`} color="info" size="sm">
                        <FontAwesomeIcon icon="eye" />{' '}
                        <span className="d-none d-md-inline">
                          <Translate contentKey="entity.action.view">View</Translate>
                        </span>
                      </Button>
                      <Button tag={Link} to={`${match.url}/${investment.id}/edit`} color="primary" size="sm">
                        <FontAwesomeIcon icon="pencil-alt" />{' '}
                        <span className="d-none d-md-inline">
                          <Translate contentKey="entity.action.edit">Edit</Translate>
                        </span>
                      </Button>
                      <Button tag={Link} to={`${match.url}/${investment.id}/delete`} color="danger" size="sm">
                        <FontAwesomeIcon icon="trash" />{' '}
                        <span className="d-none d-md-inline">
                          <Translate contentKey="entity.action.delete">Delete</Translate>
                        </span>
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        ) : (
          !loading && (
            <div className="alert alert-warning">
              <Translate contentKey="sudefiApp.investment.home.notFound">No Investments found</Translate>
            </div>
          )
        )}
      </div>
    </div>
  );
};

const mapStateToProps = ({ investment }: IRootState) => ({
  investmentList: investment.entities,
  loading: investment.loading
});

const mapDispatchToProps = {
  getEntities
};

type StateProps = ReturnType<typeof mapStateToProps>;
type DispatchProps = typeof mapDispatchToProps;

export default connect(mapStateToProps, mapDispatchToProps)(Investment);
