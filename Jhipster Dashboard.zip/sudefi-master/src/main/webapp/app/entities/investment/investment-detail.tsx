import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { Link, RouteComponentProps } from 'react-router-dom';
import { Button, Row, Col } from 'reactstrap';
import { Translate, ICrudGetAction, TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { IRootState } from 'app/shared/reducers';
import { getEntity } from './investment.reducer';
import { IInvestment } from 'app/shared/model/investment.model';
import { APP_DATE_FORMAT, APP_LOCAL_DATE_FORMAT } from 'app/config/constants';

export interface IInvestmentDetailProps extends StateProps, DispatchProps, RouteComponentProps<{ id: string }> {}

export const InvestmentDetail = (props: IInvestmentDetailProps) => {
  useEffect(() => {
    props.getEntity(props.match.params.id);
  }, []);

  const { investmentEntity } = props;
  return (
    <Row>
      <Col md="8">
        <h2>
          <Translate contentKey="sudefiApp.investment.detail.title">Investment</Translate> [<b>{investmentEntity.id}</b>]
        </h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="nature">
              <Translate contentKey="sudefiApp.investment.nature">Nature</Translate>
            </span>
          </dt>
          <dd>{investmentEntity.nature}</dd>
          <dt>
            <span id="dateCreation">
              <Translate contentKey="sudefiApp.investment.dateCreation">Date Creation</Translate>
            </span>
          </dt>
          <dd>
            <TextFormat value={investmentEntity.dateCreation} type="date" format={APP_DATE_FORMAT} />
          </dd>
          <dt>
            <span id="valueUs">
              <Translate contentKey="sudefiApp.investment.valueUs">Value Us</Translate>
            </span>
          </dt>
          <dd>{investmentEntity.valueUs}</dd>
          <dt>
            <span id="valueDollar">
              <Translate contentKey="sudefiApp.investment.valueDollar">Value Dollar</Translate>
            </span>
          </dt>
          <dd>{investmentEntity.valueDollar}</dd>
          <dt>
            <span id="addresswallet">
              <Translate contentKey="sudefiApp.investment.addresswallet">Addresswallet</Translate>
            </span>
          </dt>
          <dd>{investmentEntity.addresswallet}</dd>
          <dt>
            <span id="depositEth">
              <Translate contentKey="sudefiApp.investment.depositEth">Deposit Eth</Translate>
            </span>
          </dt>
          <dd>{investmentEntity.depositEth}</dd>
          <dt>
            <span id="bonusEth">
              <Translate contentKey="sudefiApp.investment.bonusEth">Bonus Eth</Translate>
            </span>
          </dt>
          <dd>{investmentEntity.bonusEth}</dd>
          <dt>
            <span id="idchild">
              <Translate contentKey="sudefiApp.investment.idchild">Idchild</Translate>
            </span>
          </dt>
          <dd>{investmentEntity.idchild}</dd>
          <dt>
            <span id="profitEth">
              <Translate contentKey="sudefiApp.investment.profitEth">Profit Eth</Translate>
            </span>
          </dt>
          <dd>{investmentEntity.profitEth}</dd>
          <dt>
            <span id="consolidationvalueEth">
              <Translate contentKey="sudefiApp.investment.consolidationvalueEth">Consolidationvalue Eth</Translate>
            </span>
          </dt>
          <dd>{investmentEntity.consolidationvalueEth}</dd>
          <dt>
            <span id="refidchild">
              <Translate contentKey="sudefiApp.investment.refidchild">Refidchild</Translate>
            </span>
          </dt>
          <dd>{investmentEntity.refidchild}</dd>
          <dt>
            <Translate contentKey="sudefiApp.investment.investorid">Investorid</Translate>
          </dt>
          <dd>{investmentEntity.investorid ? investmentEntity.investorid.id : ''}</dd>
        </dl>
        <Button tag={Link} to="/investment" replace color="info">
          <FontAwesomeIcon icon="arrow-left" />{' '}
          <span className="d-none d-md-inline">
            <Translate contentKey="entity.action.back">Back</Translate>
          </span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/investment/${investmentEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" />{' '}
          <span className="d-none d-md-inline">
            <Translate contentKey="entity.action.edit">Edit</Translate>
          </span>
        </Button>
      </Col>
    </Row>
  );
};

const mapStateToProps = ({ investment }: IRootState) => ({
  investmentEntity: investment.entity
});

const mapDispatchToProps = { getEntity };

type StateProps = ReturnType<typeof mapStateToProps>;
type DispatchProps = typeof mapDispatchToProps;

export default connect(mapStateToProps, mapDispatchToProps)(InvestmentDetail);
