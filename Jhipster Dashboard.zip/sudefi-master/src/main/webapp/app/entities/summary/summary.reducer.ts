import axios from 'axios';
import { ICrudGetAction, ICrudGetAllAction, ICrudPutAction, ICrudDeleteAction } from 'react-jhipster';

import { cleanEntity } from 'app/shared/util/entity-utils';
import { REQUEST, SUCCESS, FAILURE } from 'app/shared/reducers/action-type.util';

import { ISummary, defaultValue } from 'app/shared/model/summary.model';

export const ACTION_TYPES = {
  FETCH_SUMMARY_LIST: 'summary/FETCH_SUMMARY_LIST',
  FETCH_SUMMARY: 'summary/FETCH_SUMMARY',
  CREATE_SUMMARY: 'summary/CREATE_SUMMARY',
  UPDATE_SUMMARY: 'summary/UPDATE_SUMMARY',
  DELETE_SUMMARY: 'summary/DELETE_SUMMARY',
  RESET: 'summary/RESET'
};

const initialState = {
  loading: false,
  errorMessage: null,
  entities: [] as ReadonlyArray<ISummary>,
  entity: defaultValue,
  updating: false,
  updateSuccess: false
};

export type SummaryState = Readonly<typeof initialState>;

// Reducer

export default (state: SummaryState = initialState, action): SummaryState => {
  switch (action.type) {
    case REQUEST(ACTION_TYPES.FETCH_SUMMARY_LIST):
    case REQUEST(ACTION_TYPES.FETCH_SUMMARY):
      return {
        ...state,
        errorMessage: null,
        updateSuccess: false,
        loading: true
      };
    case REQUEST(ACTION_TYPES.CREATE_SUMMARY):
    case REQUEST(ACTION_TYPES.UPDATE_SUMMARY):
    case REQUEST(ACTION_TYPES.DELETE_SUMMARY):
      return {
        ...state,
        errorMessage: null,
        updateSuccess: false,
        updating: true
      };
    case FAILURE(ACTION_TYPES.FETCH_SUMMARY_LIST):
    case FAILURE(ACTION_TYPES.FETCH_SUMMARY):
    case FAILURE(ACTION_TYPES.CREATE_SUMMARY):
    case FAILURE(ACTION_TYPES.UPDATE_SUMMARY):
    case FAILURE(ACTION_TYPES.DELETE_SUMMARY):
      return {
        ...state,
        loading: false,
        updating: false,
        updateSuccess: false,
        errorMessage: action.payload
      };
    case SUCCESS(ACTION_TYPES.FETCH_SUMMARY_LIST):
      return {
        ...state,
        loading: false,
        entities: action.payload.data
      };
    case SUCCESS(ACTION_TYPES.FETCH_SUMMARY):
      return {
        ...state,
        loading: false,
        entity: action.payload.data
      };
    case SUCCESS(ACTION_TYPES.CREATE_SUMMARY):
    case SUCCESS(ACTION_TYPES.UPDATE_SUMMARY):
      return {
        ...state,
        updating: false,
        updateSuccess: true,
        entity: action.payload.data
      };
    case SUCCESS(ACTION_TYPES.DELETE_SUMMARY):
      return {
        ...state,
        updating: false,
        updateSuccess: true,
        entity: {}
      };
    case ACTION_TYPES.RESET:
      return {
        ...initialState
      };
    default:
      return state;
  }
};

const apiUrl = 'api/summaries';

// Actions

export const getEntities: ICrudGetAllAction<ISummary> = (page, size, sort) => ({
  type: ACTION_TYPES.FETCH_SUMMARY_LIST,
  payload: axios.get<ISummary>(`${apiUrl}?cacheBuster=${new Date().getTime()}`)
});

export const getEntity: ICrudGetAction<ISummary> = id => {
  const requestUrl = `${apiUrl}/${id}`;
  return {
    type: ACTION_TYPES.FETCH_SUMMARY,
    payload: axios.get<ISummary>(requestUrl)
  };
};

export const createEntity: ICrudPutAction<ISummary> = entity => async dispatch => {
  const result = await dispatch({
    type: ACTION_TYPES.CREATE_SUMMARY,
    payload: axios.post(apiUrl, cleanEntity(entity))
  });
  dispatch(getEntities());
  return result;
};

export const updateEntity: ICrudPutAction<ISummary> = entity => async dispatch => {
  const result = await dispatch({
    type: ACTION_TYPES.UPDATE_SUMMARY,
    payload: axios.put(apiUrl, cleanEntity(entity))
  });
  return result;
};

export const deleteEntity: ICrudDeleteAction<ISummary> = id => async dispatch => {
  const requestUrl = `${apiUrl}/${id}`;
  const result = await dispatch({
    type: ACTION_TYPES.DELETE_SUMMARY,
    payload: axios.delete(requestUrl)
  });
  return result;
};

export const reset = () => ({
  type: ACTION_TYPES.RESET
});
