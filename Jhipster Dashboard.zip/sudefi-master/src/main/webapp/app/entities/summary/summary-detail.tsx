import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { Link, RouteComponentProps } from 'react-router-dom';
import { Button, Row, Col } from 'reactstrap';
import { Translate, ICrudGetAction, TextFormat } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { IRootState } from 'app/shared/reducers';
import { getEntity } from './summary.reducer';
import { ISummary } from 'app/shared/model/summary.model';
import { APP_DATE_FORMAT, APP_LOCAL_DATE_FORMAT } from 'app/config/constants';

export interface ISummaryDetailProps extends StateProps, DispatchProps, RouteComponentProps<{ id: string }> {}

export const SummaryDetail = (props: ISummaryDetailProps) => {
  useEffect(() => {
    props.getEntity(props.match.params.id);
  }, []);

  const { summaryEntity } = props;
  return (
    <Row>
      <Col md="8">
        <h2>
          <Translate contentKey="sudefiApp.summary.detail.title">Summary</Translate> [<b>{summaryEntity.id}</b>]
        </h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="nature">
              <Translate contentKey="sudefiApp.summary.nature">Nature</Translate>
            </span>
          </dt>
          <dd>{summaryEntity.nature}</dd>
          <dt>
            <span id="dateCreation">
              <Translate contentKey="sudefiApp.summary.dateCreation">Date Creation</Translate>
            </span>
          </dt>
          <dd>
            <TextFormat value={summaryEntity.dateCreation} type="date" format={APP_DATE_FORMAT} />
          </dd>
          <dt>
            <span id="bonusEth">
              <Translate contentKey="sudefiApp.summary.bonusEth">Bonus Eth</Translate>
            </span>
          </dt>
          <dd>{summaryEntity.bonusEth}</dd>
          <dt>
            <span id="bonusDollar">
              <Translate contentKey="sudefiApp.summary.bonusDollar">Bonus Dollar</Translate>
            </span>
          </dt>
          <dd>{summaryEntity.bonusDollar}</dd>
          <dt>
            <span id="depositEth">
              <Translate contentKey="sudefiApp.summary.depositEth">Deposit Eth</Translate>
            </span>
          </dt>
          <dd>{summaryEntity.depositEth}</dd>
          <dt>
            <span id="depositDollar">
              <Translate contentKey="sudefiApp.summary.depositDollar">Deposit Dollar</Translate>
            </span>
          </dt>
          <dd>{summaryEntity.depositDollar}</dd>
          <dt>
            <span id="profitEth">
              <Translate contentKey="sudefiApp.summary.profitEth">Profit Eth</Translate>
            </span>
          </dt>
          <dd>{summaryEntity.profitEth}</dd>
          <dt>
            <span id="profitDollar">
              <Translate contentKey="sudefiApp.summary.profitDollar">Profit Dollar</Translate>
            </span>
          </dt>
          <dd>{summaryEntity.profitDollar}</dd>
          <dt>
            <span id="withdrawEth">
              <Translate contentKey="sudefiApp.summary.withdrawEth">Withdraw Eth</Translate>
            </span>
          </dt>
          <dd>{summaryEntity.withdrawEth}</dd>
          <dt>
            <span id="withdrawDollar">
              <Translate contentKey="sudefiApp.summary.withdrawDollar">Withdraw Dollar</Translate>
            </span>
          </dt>
          <dd>{summaryEntity.withdrawDollar}</dd>
          <dt>
            <span id="acccountBalance">
              <Translate contentKey="sudefiApp.summary.acccountBalance">Acccount Balance</Translate>
            </span>
          </dt>
          <dd>{summaryEntity.acccountBalance}</dd>
          <dt>
            <Translate contentKey="sudefiApp.summary.investorid">Investorid</Translate>
          </dt>
          <dd>{summaryEntity.investorid ? summaryEntity.investorid.id : ''}</dd>
        </dl>
        <Button tag={Link} to="/summary" replace color="info">
          <FontAwesomeIcon icon="arrow-left" />{' '}
          <span className="d-none d-md-inline">
            <Translate contentKey="entity.action.back">Back</Translate>
          </span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/summary/${summaryEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" />{' '}
          <span className="d-none d-md-inline">
            <Translate contentKey="entity.action.edit">Edit</Translate>
          </span>
        </Button>
      </Col>
    </Row>
  );
};

const mapStateToProps = ({ summary }: IRootState) => ({
  summaryEntity: summary.entity
});

const mapDispatchToProps = { getEntity };

type StateProps = ReturnType<typeof mapStateToProps>;
type DispatchProps = typeof mapDispatchToProps;

export default connect(mapStateToProps, mapDispatchToProps)(SummaryDetail);
