import React, { useState, useEffect } from 'react';
import { connect } from 'react-redux';
import { Link, RouteComponentProps } from 'react-router-dom';
import { Button, Row, Col, Label } from 'reactstrap';
import { AvFeedback, AvForm, AvGroup, AvInput, AvField } from 'availity-reactstrap-validation';
import { Translate, translate, ICrudGetAction, ICrudGetAllAction, ICrudPutAction } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { IRootState } from 'app/shared/reducers';

import { IInvestor } from 'app/shared/model/investor.model';
import { getEntities as getInvestors } from 'app/entities/investor/investor.reducer';
import { getEntity, updateEntity, createEntity, reset } from './summary.reducer';
import { ISummary } from 'app/shared/model/summary.model';
import { convertDateTimeFromServer, convertDateTimeToServer, displayDefaultDateTime } from 'app/shared/util/date-utils';
import { mapIdList } from 'app/shared/util/entity-utils';

export interface ISummaryUpdateProps extends StateProps, DispatchProps, RouteComponentProps<{ id: string }> {}

export const SummaryUpdate = (props: ISummaryUpdateProps) => {
  const [investoridId, setInvestoridId] = useState('0');
  const [isNew, setIsNew] = useState(!props.match.params || !props.match.params.id);

  const { summaryEntity, investors, loading, updating } = props;

  const handleClose = () => {
    props.history.push('/summary');
  };

  useEffect(() => {
    if (isNew) {
      props.reset();
    } else {
      props.getEntity(props.match.params.id);
    }

    props.getInvestors();
  }, []);

  useEffect(() => {
    if (props.updateSuccess) {
      handleClose();
    }
  }, [props.updateSuccess]);

  const saveEntity = (event, errors, values) => {
    values.dateCreation = convertDateTimeToServer(values.dateCreation);

    if (errors.length === 0) {
      const entity = {
        ...summaryEntity,
        ...values
      };

      if (isNew) {
        props.createEntity(entity);
      } else {
        props.updateEntity(entity);
      }
    }
  };

  return (
    <div>
      <Row className="justify-content-center">
        <Col md="8">
          <h2 id="sudefiApp.summary.home.createOrEditLabel">
            <Translate contentKey="sudefiApp.summary.home.createOrEditLabel">Create or edit a Summary</Translate>
          </h2>
        </Col>
      </Row>
      <Row className="justify-content-center">
        <Col md="8">
          {loading ? (
            <p>Loading...</p>
          ) : (
            <AvForm model={isNew ? {} : summaryEntity} onSubmit={saveEntity}>
              {!isNew ? (
                <AvGroup>
                  <Label for="summary-id">
                    <Translate contentKey="global.field.id">ID</Translate>
                  </Label>
                  <AvInput id="summary-id" type="text" className="form-control" name="id" required readOnly />
                </AvGroup>
              ) : null}
              <AvGroup>
                <Label id="natureLabel" for="summary-nature">
                  <Translate contentKey="sudefiApp.summary.nature">Nature</Translate>
                </Label>
                <AvField
                  id="summary-nature"
                  type="text"
                  name="nature"
                  validate={{
                    required: { value: true, errorMessage: translate('entity.validation.required') },
                    maxLength: { value: 1, errorMessage: translate('entity.validation.maxlength', { max: 1 }) }
                  }}
                />
              </AvGroup>
              <AvGroup>
                <Label id="dateCreationLabel" for="summary-dateCreation">
                  <Translate contentKey="sudefiApp.summary.dateCreation">Date Creation</Translate>
                </Label>
                <AvInput
                  id="summary-dateCreation"
                  type="datetime-local"
                  className="form-control"
                  name="dateCreation"
                  placeholder={'YYYY-MM-DD HH:mm'}
                  value={isNew ? displayDefaultDateTime() : convertDateTimeFromServer(props.summaryEntity.dateCreation)}
                />
              </AvGroup>
              <AvGroup>
                <Label id="bonusEthLabel" for="summary-bonusEth">
                  <Translate contentKey="sudefiApp.summary.bonusEth">Bonus Eth</Translate>
                </Label>
                <AvField id="summary-bonusEth" type="text" name="bonusEth" />
              </AvGroup>
              <AvGroup>
                <Label id="bonusDollarLabel" for="summary-bonusDollar">
                  <Translate contentKey="sudefiApp.summary.bonusDollar">Bonus Dollar</Translate>
                </Label>
                <AvField id="summary-bonusDollar" type="text" name="bonusDollar" />
              </AvGroup>
              <AvGroup>
                <Label id="depositEthLabel" for="summary-depositEth">
                  <Translate contentKey="sudefiApp.summary.depositEth">Deposit Eth</Translate>
                </Label>
                <AvField id="summary-depositEth" type="text" name="depositEth" />
              </AvGroup>
              <AvGroup>
                <Label id="depositDollarLabel" for="summary-depositDollar">
                  <Translate contentKey="sudefiApp.summary.depositDollar">Deposit Dollar</Translate>
                </Label>
                <AvField id="summary-depositDollar" type="text" name="depositDollar" />
              </AvGroup>
              <AvGroup>
                <Label id="profitEthLabel" for="summary-profitEth">
                  <Translate contentKey="sudefiApp.summary.profitEth">Profit Eth</Translate>
                </Label>
                <AvField id="summary-profitEth" type="text" name="profitEth" />
              </AvGroup>
              <AvGroup>
                <Label id="profitDollarLabel" for="summary-profitDollar">
                  <Translate contentKey="sudefiApp.summary.profitDollar">Profit Dollar</Translate>
                </Label>
                <AvField id="summary-profitDollar" type="text" name="profitDollar" />
              </AvGroup>
              <AvGroup>
                <Label id="withdrawEthLabel" for="summary-withdrawEth">
                  <Translate contentKey="sudefiApp.summary.withdrawEth">Withdraw Eth</Translate>
                </Label>
                <AvField id="summary-withdrawEth" type="text" name="withdrawEth" />
              </AvGroup>
              <AvGroup>
                <Label id="withdrawDollarLabel" for="summary-withdrawDollar">
                  <Translate contentKey="sudefiApp.summary.withdrawDollar">Withdraw Dollar</Translate>
                </Label>
                <AvField id="summary-withdrawDollar" type="text" name="withdrawDollar" />
              </AvGroup>
              <AvGroup>
                <Label id="acccountBalanceLabel" for="summary-acccountBalance">
                  <Translate contentKey="sudefiApp.summary.acccountBalance">Acccount Balance</Translate>
                </Label>
                <AvField id="summary-acccountBalance" type="text" name="acccountBalance" />
              </AvGroup>
              <AvGroup>
                <Label for="summary-investorid">
                  <Translate contentKey="sudefiApp.summary.investorid">Investorid</Translate>
                </Label>
                <AvInput id="summary-investorid" type="select" className="form-control" name="investorid.id">
                  <option value="" key="0" />
                  {investors
                    ? investors.map(otherEntity => (
                        <option value={otherEntity.id} key={otherEntity.id}>
                          {otherEntity.id}
                        </option>
                      ))
                    : null}
                </AvInput>
              </AvGroup>
              <Button tag={Link} id="cancel-save" to="/summary" replace color="info">
                <FontAwesomeIcon icon="arrow-left" />
                &nbsp;
                <span className="d-none d-md-inline">
                  <Translate contentKey="entity.action.back">Back</Translate>
                </span>
              </Button>
              &nbsp;
              <Button color="primary" id="save-entity" type="submit" disabled={updating}>
                <FontAwesomeIcon icon="save" />
                &nbsp;
                <Translate contentKey="entity.action.save">Save</Translate>
              </Button>
            </AvForm>
          )}
        </Col>
      </Row>
    </div>
  );
};

const mapStateToProps = (storeState: IRootState) => ({
  investors: storeState.investor.entities,
  summaryEntity: storeState.summary.entity,
  loading: storeState.summary.loading,
  updating: storeState.summary.updating,
  updateSuccess: storeState.summary.updateSuccess
});

const mapDispatchToProps = {
  getInvestors,
  getEntity,
  updateEntity,
  createEntity,
  reset
};

type StateProps = ReturnType<typeof mapStateToProps>;
type DispatchProps = typeof mapDispatchToProps;

export default connect(mapStateToProps, mapDispatchToProps)(SummaryUpdate);
