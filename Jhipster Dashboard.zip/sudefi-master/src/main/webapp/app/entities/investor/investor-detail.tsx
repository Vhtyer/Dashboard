import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { Link, RouteComponentProps } from 'react-router-dom';
import { Button, Row, Col } from 'reactstrap';
import { Translate, ICrudGetAction } from 'react-jhipster';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import { IRootState } from 'app/shared/reducers';
import { getEntity } from './investor.reducer';
import { IInvestor } from 'app/shared/model/investor.model';
import { APP_DATE_FORMAT, APP_LOCAL_DATE_FORMAT } from 'app/config/constants';

export interface IInvestorDetailProps extends StateProps, DispatchProps, RouteComponentProps<{ id: string }> {}

export const InvestorDetail = (props: IInvestorDetailProps) => {
  useEffect(() => {
    props.getEntity(props.match.params.id);
  }, []);

  const { investorEntity } = props;
  return (
    <Row>
      <Col md="8">
        <h2>
          <Translate contentKey="sudefiApp.investor.detail.title">Investor</Translate> [<b>{investorEntity.id}</b>]
        </h2>
        <dl className="jh-entity-details">
          <dt>
            <span id="pais">
              <Translate contentKey="sudefiApp.investor.pais">Pais</Translate>
            </span>
          </dt>
          <dd>{investorEntity.pais}</dd>
          <dt>
            <span id="addresswallet">
              <Translate contentKey="sudefiApp.investor.addresswallet">Addresswallet</Translate>
            </span>
          </dt>
          <dd>{investorEntity.addresswallet}</dd>
          <dt>
            <span id="firstname">
              <Translate contentKey="sudefiApp.investor.firstname">Firstname</Translate>
            </span>
          </dt>
          <dd>{investorEntity.firstname}</dd>
          <dt>
            <span id="lastname">
              <Translate contentKey="sudefiApp.investor.lastname">Lastname</Translate>
            </span>
          </dt>
          <dd>{investorEntity.lastname}</dd>
          <dt>
            <span id="phoneNumber">
              <Translate contentKey="sudefiApp.investor.phoneNumber">Phone Number</Translate>
            </span>
          </dt>
          <dd>{investorEntity.phoneNumber}</dd>
          <dt>
            <span id="fatherid">
              <Translate contentKey="sudefiApp.investor.fatherid">Fatherid</Translate>
            </span>
          </dt>
          <dd>{investorEntity.fatherid}</dd>
        </dl>
        <Button tag={Link} to="/investor" replace color="info">
          <FontAwesomeIcon icon="arrow-left" />{' '}
          <span className="d-none d-md-inline">
            <Translate contentKey="entity.action.back">Back</Translate>
          </span>
        </Button>
        &nbsp;
        <Button tag={Link} to={`/investor/${investorEntity.id}/edit`} replace color="primary">
          <FontAwesomeIcon icon="pencil-alt" />{' '}
          <span className="d-none d-md-inline">
            <Translate contentKey="entity.action.edit">Edit</Translate>
          </span>
        </Button>
      </Col>
    </Row>
  );
};

const mapStateToProps = ({ investor }: IRootState) => ({
  investorEntity: investor.entity
});

const mapDispatchToProps = { getEntity };

type StateProps = ReturnType<typeof mapStateToProps>;
type DispatchProps = typeof mapDispatchToProps;

export default connect(mapStateToProps, mapDispatchToProps)(InvestorDetail);
